/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matresssales1;

/**
 *
 * @author Student
 */
public class PrintProduct {
   
    
    public PrintProduct(Product product){
        this.product = product;
        
    }
    
    public void printReport() {
          String[] names = product.getProductNames();
        String[] months = product.getMonthNames();
        int[][] sales = product.getSales();
        int[] productTotals = product.getTotalPerProduct();
        int[] monthTotals = product.getTotalPerMonth();
            
        
        System.out.println("================================================================");
        System.out.println("Matress sales Report");
     System.out.println("================================================================");
         System.out.printf("%-20s", "Product");
        for (String month : months) {
            System.out.printf("%12s", month);
        }
        System.out.printf("%12s%n", "Total");
        System.out.println("-------------------------------------------------------------------------");

        // One row per product
        for (int p = 0; p < names.length; p++) {
            System.out.printf("%-20s", names[p]);
            for (int m = 0; m < months.length; m++) {
                System.out.printf("%12d", sales[p][m]);
            }
            System.out.printf("%12d%n", productTotals[p]);
        }

        // Monthly totals row
        System.out.println("-------------------------------------------------------------------------");
        System.out.printf("%-20s", "Monthly Total");
        for (int m = 0; m < months.length; m++) {
            System.out.printf("%12d", monthTotals[m]);
        }
        System.out.printf("%12d%n", product.getTotalProductsSold());
        System.out.println("=========================================================================");

        // Summary
        System.out.println("Total number of products sold   : " + product.getTotalProductsSold());
        System.out.printf("Average products sold per product: %.2f%n", product.calculateAverageProductsSold());
        System.out.println("Most popular product            : " + product.getMostPopularProduct());
        System.out.println("=========================================================================");
    }
    }
}
