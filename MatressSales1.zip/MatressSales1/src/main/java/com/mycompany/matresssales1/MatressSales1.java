/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matresssales1;

/**
 *
 * @author Student
 */
public class MatressSales1 {

    public static void main(String[] args) {
        
        // The single use of dimensional arrays
        String[] productNames = {"Queen size Matress", "King size matress", "Double size Matress"};
       String[]  monthNames = {"January", "February" , "April"};
       
       //The use of Two dimensional arrays 
       
       int[][] sales = {
           {120,135,170},
           {96,110,105},
           {80,90,100}
       };
       
        Product product = new Product(productNames, monthNames, sales);
        PrintProduct printer = new PrintProduct(product);
        printer.printReport();
            
        }
    }

