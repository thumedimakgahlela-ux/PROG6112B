/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.matresssales1;

/**
 *
 * @author Student
 */
public interface IProduct {
 //Total number of products sold across all products and months
int GetTotalProductSold();

// Average number of products sold per product
double GetAverageProductSold();

// product with the highest total sales
String GetMostPopularProduct();
}
