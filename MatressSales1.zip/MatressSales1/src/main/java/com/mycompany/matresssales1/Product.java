/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matresssales1;

/**
 *
 * @author Student
 */
public  class Product implements IProduct {
    
  String [] productNames;
  String[] monthNames;
  int[] sale;
    
  public Product(String[] productNames, String[] monthNames, int[] sales) {
      this.productNames = productNames;
      this.monthNames = monthNames;
      this.sale = sales;
      
     
  }public int[] getTotalPerProduct() {
        int[] totals = new int[productNames.length];
        for (int p = 0; p < sales.length; p++) {
            for (int m = 0; m < sales[p].length; m++) {
                totals[p] += sales[p][m];
                
                
               
    
}
        }
        return totals;
  }
}
  @Override
    public int getTotalProductsSold() {
        int total = 0;
        for (int productTotal : getTotalPerProduct()) {
            total += productTotal;
        }
        return total;
    }

    @Override
    public double calculateAverageProductsSold() {
        return (double) getTotalProductsSold() / productNames.length;
    }

    @Override
    public String getMostPopularProduct() {
        int[] totals = getTotalPerProduct();
        int bestIndex = 0;
        for (int p = 1; p < totals.length; p++) {
            if (totals[p] > totals[bestIndex]) {
                bestIndex = p;
            }
        }
        return productNames[bestIndex];
    }

    public String[] getProductNames() {
        return productNames;
    }

    public String[] getMonthNames() {
        return monthNames;
    }

    public int[][] getSales() {
        return sales;
    }
}
