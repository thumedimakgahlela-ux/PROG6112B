/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class ProductCalculations {
   


    public static final double VAT_RATE = 0.15;          
    public static final double COMMISSION_RATE = 0.05;   
    
    
    public static double GetVat(double price) {
        return price * VAT_RATE;
    }

   
    public static double GetCommission(double price) {
        return price * COMMISSION_RATE;
    }

    
    public static double GetTotal(double price) {
        return price + GetVat(price) + GetCommission(price);
    }
}
    

