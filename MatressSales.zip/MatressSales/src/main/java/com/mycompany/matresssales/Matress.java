/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.MatressSales;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Student
 */
public class Matress extends javax.swing.JFrame {
   private static final double VAT_RATE = 0.15;
    private static final double COMMISSION_RATE = 0.05;
    private static final String FILE_NAME = "sales.txt";

    // Holds the five details of one sale
    private static class Sale {
        String customerName, productName;
        double vatAmount, commissionAmount, totalSaleAmount;

        Sale(String customerName, String productName, double price) {
            this.customerName = customerName;
            this.productName = productName;
            this.vatAmount = price * VAT_RATE;
            this.commissionAmount = price * COMMISSION_RATE;
            this.totalSaleAmount = price + vatAmount + commissionAmount;
        }
    }

    private final ArrayList<Sale> sales = new ArrayList<>();

    private JTextField txtCustomer, txtPrice, txtVat, txtCommission, txtTotal;
    private JComboBox<String> cmbProduct;
    private JButton btnProcess, btnClear;
    private DefaultTableModel tableModel; 
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Matress.class.getName());

    /**
     * Creates new form Matress
     */
    public Matress() {
       initUI ();
    }

    private void initUI() {
        setTitle("Mattress Sales");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        txtCustomer = new JTextField();
        cmbProduct = new JComboBox<>(new String[]{
            "Single Mattress", "Three-Quarter Mattress", "Double Mattress",
            "Queen Mattress", "King Mattress"});
        txtPrice = new JTextField();
        txtVat = new JTextField();
        txtCommission = new JTextField();
        txtTotal = new JTextField();
        txtVat.setEditable(false);
        txtCommission.setEditable(false);
        txtTotal.setEditable(false);

        form.add(new JLabel("Customer Name"));          form.add(txtCustomer);
        form.add(new JLabel("Select Product"));         form.add(cmbProduct);
        form.add(new JLabel("Enter Price (R)"));        form.add(txtPrice);
        form.add(new JLabel("VAT Amount (15%)"));       form.add(txtVat);
        form.add(new JLabel("Commission Amount (5%)")); form.add(txtCommission);
        form.add(new JLabel("Total Sale Amount"));      form.add(txtTotal);

        btnProcess = new JButton("Process");
        btnClear = new JButton("Clear");
        btnProcess.addActionListener(e -> processSale());
        btnClear.addActionListener(e -> clearFields());
        form.add(btnProcess);
        form.add(btnClear);

        add(form, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{
            "Customer Name", "Product Name", "VAT Amount",
            "Commission Amount", "Total Sale Amount"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        JScrollPane scroll = new JScrollPane(new JTable(tableModel));
        scroll.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        add(scroll, BorderLayout.CENTER);

        setSize(750, 500);
        setLocationRelativeTo(null);
    }

    private void processSale() {
        String customer = txtCustomer.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        if (customer.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the customer name.",
                    "Missing data", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
            if (price <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price greater than 0.",
                    "Invalid price", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Sale sale = new Sale(customer, product, price);
        sales.add(sale);                       // store in memory

        // Display on the form
        txtVat.setText(String.format("R %.2f", sale.vatAmount));
        txtCommission.setText(String.format("R %.2f", sale.commissionAmount));
        txtTotal.setText(String.format("R %.2f", sale.totalSaleAmount));

        // Display in the table
        tableModel.addRow(new Object[]{
            sale.customerName, sale.productName,
            String.format("R %.2f", sale.vatAmount),
            String.format("R %.2f", sale.commissionAmount),
            String.format("R %.2f", sale.totalSaleAmount)});

        saveToFile(sale);                      // store in file
    }

    private void saveToFile(Sale s) {
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME, true))) {
            out.printf("Customer: %s | Product: %s | VAT: %.2f | Commission: %.2f | Total: %.2f%n",
                    s.customerName, s.productName, s.vatAmount,
                    s.commissionAmount, s.totalSaleAmount);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save to file: " + ex.getMessage(),
                    "File error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        txtCustomer.setText("");
        txtPrice.setText("");
        txtVat.setText("");
        txtCommission.setText("");
        txtTotal.setText("");
        cmbProduct.setSelectedIndex(0);
        txtCustomer.requestFocus();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Customer Name");

        jLabel3.setText("Select Product");

        jLabel4.setText("Enter price");

        jButton1.setText("Process");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jTextField1)
                        .addComponent(jComboBox1, 0, 149, Short.MAX_VALUE)
                        .addComponent(jTextField2)))
                .addContainerGap(79, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addComponent(jButton1)
                .addContainerGap(102, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            // fall back to the default look and feel
        }
        EventQueue.invokeLater(() -> new Matress().setVisible(true));
    }
}
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Matress().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
