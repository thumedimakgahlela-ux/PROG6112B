/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matresssales;

/**
 *
 * @author Student
 */
public class MatressSales {

    public static void main(String[] args) {
       
    }
}
